package com.sabrina.daniel.Livratech.model;

public class DomainEntity {
}
